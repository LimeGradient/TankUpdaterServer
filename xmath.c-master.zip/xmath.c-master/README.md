# About
math.c is the repo for xmath.c, a math library written in C by LimeGradient

<br>

# How to Use
Run <code>git clone https://github.com/LimeGradient/xmath.c.git</code>
<br>In your main.c file do <code>#include <math/xmath.h></code>
<br>Dev used compile script: <code>cc main.c math/xmath.c -o main